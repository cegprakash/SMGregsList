chrome.extension.sendMessage([5, document.body.innerHTML], function(response) {

  });